import React from 'react';
import {Text, View, FlatList, Button } from 'react-native'
import CStyles from '../Styles/CalendarStyles'


export default class CalendarScreen extends React.Component {
    static navigationOptions = {
        title: 'Diet Tracker',
        headerStyle: {
          backgroundColor: '#54AAE9',
        },
        headerTintColor: '#fff',
        headerTitleStyle: {
            fontWeight: 'bold',
            color: "black"
          },
      };
        constructor(props){
            super(props);
            const willFocusSubscription = this.props.navigation.addListener(
                'willFocus',
                this._updateState
            )

            this.state = {
                hasUpdated:  false,
                data: [
                    { key: '1' ,Day: 'Monday', 
                                Time: '12:45',
                                Task: 'Bio 1040',
                                Reminder: 'Drink water'}, 
                    { key: '2', Day: 'Monday', 
                                Time: '1:45',
                                Task: 'Chem 3040',
                                Reminder: 'Eat Lunch'}, 
                    { key: '3', Day: 'Monday',
                               Time: '3:45',
                               Task: 'Practice',
                               Reminder: 'Drink water' }, 
                    { key: '4', Day: 'Monday', 
                                Time: '6:45',
                               Task: 'Dinner',
                               Reminder: 'Eat more veggies' },
                ],

        }
        

         
            
    }
    static navigationOptions =({ navigation } = this.props.navigation) => {
        return{
            headerTitle: 'Contacts List',
            headerRight: (
            <Button
                onPress={() => navigation.navigate('Input')}
                title="Add Person"
                color="#000000"
            />
            ),
        }
      };


    _renderItem = data => {
        return(
        <View style = {CStyles.calendarItem}>
            <Text style={CStyles.text}>
                        {data.item.Day} {'\n'}{data.item.Time}
                    </Text>
            <Text style = {CStyles.text}>
                        {data.item.Task}{'\n'}{data.item.Reminder}
                    </Text>
        </View> 
        
        )};

      
            _updateState = payload => {
                const Firstname = this.props.navigation.getParam('FirstName', 'No name');
                if( Firstname != 'No name'){
                const Firstname = this.props.navigation.getParam('FirstName', 'No name');
                const Lastname = this.props.navigation.getParam('LastName', 'No name');
                const email = this.props.navigation.getParam('EmailAddy', 'No mail');
                const age = this.props.navigation.getParam('Age', 'No age');
                const updated = this.props.navigation.getParam('updated', 'false')
                this.setState({count: this.state.count + 1});
                var newData = [];
                newData = this.state.data.slice();
                newData.push({ key: '5', FirstName: Firstname, LastName: Lastname, 
                                Email: email, Age: age})
                
                this.setState({data: newData});
                }
              }

           
        
    
    render() {
        const Firstname = this.props.navigation.getParam('FirstName', 'No name');
                const Lastname = this.props.navigation.getParam('LastName', 'No name');
                const email = this.props.navigation.getParam('EmailAddy', 'No mail');
                const age = this.props.navigation.getParam('Age', 'No age');
                const updated = this.props.navigation.getParam('updated', 'false')
                var newData = [];
                newData = this.state.data.slice();
                newData.push({ key: '5', FirstName: Firstname, LastName: Lastname, 
                                Email: email, Age: age})
        return (
                <View style={CStyles.container}>
                    <FlatList data={this.state.data}
                    renderItem={this._renderItem} />
                </View>
            );
        }
}