
import { createStackNavigator, createNavigationContainer } from 'react-navigation';
import LogInScreen from './Components/LogInScreen';
import MainScreen from './Components/MainScreen';


const RootStack = createStackNavigator({
      LogIn: LogInScreen,
      Home: MainScreen

},
// {   
//   headerMode: 'none' 
// },
  {
    initialRouteName: 'LogIn',
  }
  );

  const App = createNavigationContainer(RootStack);
  
 export default  App; 
